package learn.xufei.RBT.warmup.bst.avl;/*
    @Author  87814   xufei
    @Date  2018/11/3    11:57
*//*
    @Author  87814   xufei
    @Date  2018/11/3    11:57
*/


public class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    public TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }

    public TreeNode(int val) {
        this.val = val;
    }
}
